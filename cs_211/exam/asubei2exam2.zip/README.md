# CS 211 Final Exam

Date: Wednesday, Dec. 6th

### Usage
A makefile is provided for easier compilation. Enter `make` or `make asubei2exam2` to build the project. Enter `make run` to run the executable. If you want to build and run, just enter `make all`.
Recompilation should work just fine with `make`. the source and header files are set as dependencies for the build process.

To clean up, enter `make clean`.
